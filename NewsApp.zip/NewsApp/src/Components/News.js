import React, { Component } from 'react'
import NewsItem from './NewsItem'


export class News extends Component {

    constructor() {
        super();
        this.state = {
            article: null,
            loading: false,
            page: 1


        }
    }
    async componentDidMount() {
        let url = `https://newsapi.org/v2/everything?q=bitcoin&apiKey=9ec13fc0196a45c89ca8ffd423b09fa9&page=1&pageSize=${this.props.pageSize}`;
        let data = await fetch(url);
        let parsedData = await data.json()
        this.setState({ article: parsedData.articles, totalResults: parsedData.totalResults })

    }

    handlePrevClick = async () => {


        let url = `https://newsapi.org/v2/everything?q=bitcoin&apiKey=9ec13fc0196a45c89ca8ffd423b09fa9&page=1=${this.state.page - 1}&pageSize=${this.props.pageSize}`;
        let data = await fetch(url);
        let parsedData = await data.json()
        this.setState({ article: parsedData.articles })
        this.setState({
            page: this.state.page - 1,
        })

    }

    handleNextClick = async () => {
        if (this.state.page + 1 > Math.ceil(this.state.totalResults / this.props.pageSize)) {

        } 
        else {
            let url = `https://newsapi.org/v2/everything?q=bitcoin&apiKey=9ec13fc0196a45c89ca8ffd423b09fa9&page=1=${this.state.page + 1}&pageSize=${this.props.pageSizeF}`;
            let data = await fetch(url);
            let parsedData = await data.json()
            this.setState({ article: parsedData.articles })
            this.setState({
                page: this.state.page + 1,
            })
        }
        }

        render() {
            return (

                <div className='container my-3'>
                <h1 className="text-center">NewsMonkey - Top Headlines</h1>                    
                    <div className="row">
                        {!this.state.article ? null : this.state.article.map((element) => {
                            return <div className="col-md-4" key={element.url}>
                                <NewsItem title={element.title ? element.title.slice(0, 54) : ''} description={element.description ? element.description.slice(0, 76) : ""}
                                    imageUrl={element.urlToImage} newsUrl={element.url} />

                            </div>
                        })}
                    </div>
                    <div className="container d-flex justify-content-between my-3">

                        <button disabled={this.state.page <= 1} type="button" className="btn btn-dark" onClick={this.handlePrevClick}>	&larr; Previous</button>
                        <button disabled={this.state.page + 1 > Math.ceil(this.state.totalResults /this.props.pageSize)}type="button" className="btn btn-dark" onClick={this.handleNextClick}>Next &rarr;</button>
                    </div>

                </div>
            )
        }
    }

export default News
